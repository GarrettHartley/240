package client.indexerWindow;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JToolBar;

import client.gui.BatchState;
import client.gui.BatchStateListener;
import client.indexerWindow.tableEntry.TableEntryCell;

public class ButtonMenu extends JToolBar implements BatchStateListener {
	BatchState batchState;
	JButton zoomIn = new JButton("Zoom In");
	JButton zoomOut = new JButton("Zoom Out");
	JButton invertImage = new JButton("Invert Image");
	JButton toggleHighlights = new JButton("Toggle Highlights");		
	JButton save = new JButton("Save");		
	JButton submit = new JButton("Submit");

	
	public ButtonMenu(BatchState batchState) {
		this.batchState = batchState;
		invertImage.addActionListener(al);
		zoomIn.addActionListener(al);
		zoomOut.addActionListener(al);
		toggleHighlights.addActionListener(al);
		submit.addActionListener(al);
		save.addActionListener(saveAction);
		this.add(zoomIn);
		this.add(zoomOut);
		this.add(invertImage);
		this.add(toggleHighlights);
		this.add(save);
		this.add(submit);
	//	submit.setEnabled(false);
	}
	
	
	private ActionListener al = new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			Object o = e.getSource();
			JButton button = null;
			if(o instanceof JButton){
				button = (JButton)o;
			}
			System.out.println("This is actionPerformed: "+button.getText());
				batchState.updateImage(button.getText());
		}
		
	};
	
	private ActionListener saveAction = new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			
			Object o = e.getSource();
			JButton button = null;
			if(o instanceof JButton){
				button = (JButton)o;
			}
			System.out.println("This is actionPerformed: "+button.getText());
			batchState.logout(button.getText());
		}
			
			
	
	};

	@Override
	public void downloadBatch() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void selectField() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void updateData() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void updateSelected(TableEntryCell selectedCell) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void performLogout(String function) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void updateImage(String function) {
		
	}

}
