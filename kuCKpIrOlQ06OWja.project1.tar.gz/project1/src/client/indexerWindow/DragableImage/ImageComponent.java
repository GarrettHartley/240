package client.indexerWindow.DragableImage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

@SuppressWarnings("serial")
public class ImageComponent extends JComponent{
	
	private static Image NULL_IMAGE = new BufferedImage(10,10,BufferedImage.TYPE_INT_ARGB);
	Image dragImage;
	
	private Point2D lastPoint;
	
	public ImageComponent(){
		this.setBackground(new Color (178, 223,210));
		this.setPreferredSize(new Dimension(700,700));
		
		this.addMouseListener(mouseAdapter);
		

		
	}
	
	private Image loadImage(String imageFile){
		try{
			return ImageIO.read(new File(imageFile));
		}
		catch (IOException e){
			return NULL_IMAGE;
		}
	}
	
	private MouseAdapter mouseAdapter = new MouseAdapter() {

//		@Override
//		public void mouseDragged(MouseEvent e) {
////			
////			int dx = e.getX() - (int)lastPoint.getX();
////			int dy = e.getY() - (int)lastPoint.getY();
////			
////			for (DrawingShape s : dragShapes) {
////				dragImage.adjustPosition(dx, dy);
////			}
////			
////			lastPoint = new Point2D.Double(e.getX(), e.getY());
////			
////			DraggingComponent.this.repaint();
//		}

		@Override
		public void mousePressed(MouseEvent e) {
			int d_X = e.getX();
			int d_Y = e.getY();
			System.out.println(d_X);
			System.out.println(d_Y);
		}

//		@Override
//		public void mouseReleased(MouseEvent e) {
////			dragShapes.clear();
////			lastPoint = null;
//		}
//
//		@Override
//		public void mouseWheelMoved(MouseWheelEvent e) {
////			int scrollAmount = 0;
////			if (e.getScrollType() == MouseWheelEvent.WHEEL_UNIT_SCROLL) {
////				scrollAmount = e.getUnitsToScroll();
////			} else {
////				scrollAmount = e.getWheelRotation();
////			}
////			
////			int dx = 0;
////			int dy = 0;
////			if (e.isShiftDown()) {
////				dx = scrollAmount;
////				dy = 0;
////			}
////			else {
////				dx = 0;
////				dy = scrollAmount;
////			}
////			
////			adjustShapePositions(dx, dy);
//		}	
	};
	
	
	
	
}
