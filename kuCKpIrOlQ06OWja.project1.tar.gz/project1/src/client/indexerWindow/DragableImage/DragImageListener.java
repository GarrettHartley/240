package client.indexerWindow.DragableImage;

public interface DragImageListener {
	void translationChanged(int w_newTranslateX, int w_newTranslateY);
}
