package dataImporter;

import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import server.ServerFacade;
import server.database.Database;
import server.database.DatabaseException;
import server.database.DAO.BatchDAO;
import server.database.DAO.FieldDAO;
import server.database.DAO.ProjectDAO;
import server.database.DAO.UserDAO;
import server.database.DAO.ValueDAO;
import server.handlers.ServerException;
import shared.communicationClasses.Download_batch_param;
import shared.communicationClasses.Download_batch_result;
import shared.communicationClasses.Get_fields_param;
import shared.communicationClasses.Get_fields_result;
import shared.communicationClasses.Get_projects_param;
import shared.communicationClasses.Get_projects_result;
import shared.communicationClasses.Get_sampleImage_param;
import shared.communicationClasses.Get_sampleImage_result;
import shared.communicationClasses.Search_param;
import shared.communicationClasses.Search_result;
import shared.communicationClasses.Submit_batch_param;
import shared.communicationClasses.Submit_batch_result;
import shared.communicationClasses.Validate_user_param;
import shared.communicationClasses.Validate_user_result;
import shared.modelClasses.Batch;
import shared.modelClasses.Field;
import shared.modelClasses.Project;
import shared.modelClasses.User;
import shared.modelClasses.Value;

/**
 * @author hartley9
 *
 */
public class DataImporter {

	private static Database db;
	
	public DataImporter(Database db) {
		this.db = db;
	}

	public void init(){
		PreparedStatement stmt = null;
		String deleteProjects = "drop table if exists projects;";
		String deleteUsers = "drop table if exists users;";
		String deleteFields = "drop table if exists fields;";
		String deleteBatches = "drop table if exists batches;";
		String deleteValues = "drop table if exists valuesInfo;";
		
		String createProjects = "CREATE TABLE projects ("+
				"primaryID INTEGER PRIMARY KEY  AUTOINCREMENT NOT NULL UNIQUE ,"+ 
				"title VARCHAR NOT NULL ,"+
				"recordsperimage INTEGER NOT NULL  DEFAULT 1,"+
				"firstycoord INTEGER NOT NULL  DEFAULT 0,"+
				"recordheight INTEGER NOT NULL  DEFAULT 1,"+
				"numberfields INTEGER NOT NULL  DEFAULT 0)";
		
		String createUsers = "CREATE TABLE users ("+
				"primaryID INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE  DEFAULT 1,"+
				"username VARCHAR NOT NULL  UNIQUE ,"+ 
				"password VARCHAR NOT NULL ,"+ 
				"firstname CHAR NOT NULL ,"+
				"lastname CHAR NOT NULL ,"+
				"numrecords INTEGER NOT NULL  DEFAULT 0,"+
				"hasbatch BOOLEAN DEFAULT false,"+
				"email VARCHAR NOT NULL  UNIQUE );";
		
		String createFields = "CREATE TABLE fields ("+
				"primaryID INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE ,"+
				"foreignProjectKey INTEGER NOT NULL ,"+
				"title VARCHAR NOT NULL ,"+ 
				"xcoord INTEGER NOT NULL  DEFAULT 0,"+ 
				"width INTEGER NOT NULL  DEFAULT 1,"+ 
				"helphtml VARCHAR NOT NULL ,"+
				"knowndata VARCHAR,"+
				"fieldNumber INTEGER NOT NULL);";
		
		String createBatches = "CREATE TABLE batches ("+
				"primaryID INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE ,"+
				"foreignProjectKey INTEGER NOT NULL ,"+ 
				"foreignUserKey INTEGER NOT NULL ,"+ 
				"file VARCHAR NOT NULL);";
		
		String createValues ="CREATE TABLE valuesInfo ("+ 
				"foreignImageKey INTEGER NOT NULL ,"+ 
				"foreignFieldKey INTEGER NOT NULL ,"+
				"col INTEGER NOT NULL ,"+ 
				"row INTEGER NOT NULL ,"+ 
				"value VARCHAR NOT NULL );";
				
		

		try {
			stmt = db.getConnection().prepareStatement(deleteProjects);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(createProjects);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(deleteUsers);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(createUsers);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(deleteFields);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(createFields);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(deleteBatches);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(createBatches);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(deleteValues);
			stmt.execute();
			stmt = db.getConnection().prepareStatement(createValues);
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	public static String getValue(Element e){
		String result = "";
		Node child = e.getFirstChild();
		result = child.getNodeValue();
		return result;
	}
	
	/**
	 * @param args
	 * creates an instance of indexerData, which is the root of the data model
	 */
	public static void main(String[] args) {
		File xmlInput = new File(args[0]);
		File xmlDestination = new File("database");

		try {
			FileUtils.copyDirectory(xmlInput.getParentFile(), xmlDestination);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dbBuilder = null;
		try {
		dbBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		
		Document document = null;
		
		if(dbBuilder!=null){
			try {
				document = dbBuilder.parse(xmlInput);
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		document.getDocumentElement().normalize();
		Element root = document.getDocumentElement();
		
		IndexerData indexerData = new IndexerData(root);
		
		ArrayList<Project> projects = indexerData.getProjects();
		ArrayList<User> users = indexerData.getUsers();
		
		
		Database db = new Database();
		
		try {
			db.startTransaction();
			db.getDataImporter().init();
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		UserDAO uDAO = new UserDAO(db);
		for(User u:users){
			uDAO.insert(u);
		}
		ProjectDAO pDAO = new ProjectDAO(db);
		BatchDAO bDAO = new BatchDAO(db);
		FieldDAO fDAO = new FieldDAO(db);
		ValueDAO vDAO = new ValueDAO(db);
		ArrayList<Field> fields = new ArrayList<Field>();
		ArrayList<Batch> batches = new ArrayList<Batch>();
		ArrayList<Value> values = new ArrayList<Value>();
		int col= 0;
		int row= 1;
		int fieldNumber=1;
		for(Project p:projects){
			pDAO.insert(p);
			fields= p.getFields();
			batches = p.getBatches();
			
			for(Field f:fields){
				f.setForeignProjectKey(p.getPrimaryID());
				f.setFieldNumber(fieldNumber);
				fDAO.insert(f);
				fieldNumber++;
				if(fieldNumber == fields.size()+1){
					fieldNumber = 1;
				}
			}

			for(Batch b: batches){
				b.setForeignProjectKey(p.getPrimaryID());
				bDAO.insert(b);
				values = b.getValues();
				row = 1;
				for(Value v: values){
					bDAO.setComplete(b.getPrimaryID());
					v.setForeignImageKey(b.getPrimaryID());
					v.setForeignFieldKey(fields.get(col).getPrimaryID());
					v.setCol(col+1);
					v.setRow(row);
					vDAO.insert(v);
					col++;
					if(col == fields.size()){
						col=0;
						row++;
					}
				}	
			}
		}
		db.endTransaction(true);
		
//		
//		
//		ServerFacade sf = new ServerFacade();
//		Validate_user_param param = new Validate_user_param();
//		Get_projects_param Gparam = new Get_projects_param();
//		Get_sampleImage_param Bparam = new Get_sampleImage_param();
//		Download_batch_param dparam = new Download_batch_param();
//		Get_fields_param gfparam = new Get_fields_param();
//		Submit_batch_param sbparam = new Submit_batch_param();
//		Search_param sparam = new Search_param();
//		param.setPassword("test1");
//		param.setUser("test1");
//		Gparam.setPassword("test1");
//		Gparam.setUser("test1");
//		Bparam.setPassword("test1");
//		Bparam.setUser("test1");
//		Bparam.setProjectID(2);
//		dparam.setPassword("test1");
//		dparam.setUser("test1");
//		dparam.setProjectID(1);
//		gfparam.setPassword("test1");
//		gfparam.setUser("test1");
//		gfparam.setProjectID(3);
//		sbparam.setBatchID(45);
//		sbparam.setFieldValues( "Jones,Fred,13,hey;Rogers,Susan,42,hey;,,,hey;,,,hey;Van Fleet,Bill,23,hey");
//		sbparam.setPassword("test1");
//		sbparam.setUser("test1");
//		sparam.setPassword("test1");
//		sparam.setUser("test1");
//		String fieldsToSearch = "12";
//		String valuesToSearch = "20";
//		sparam.setFieldsToSearch(fieldsToSearch);
//		sparam.setSearchValues(valuesToSearch);
//	
//		
//		
//		
//
//		try {
////			Get_projects_result gpresult = sf.getProjects(Gparam);
////		
//////			System.out.println(gpresult.toString());
////
////			Validate_user_result vRsult;
////			vRsult = sf.validateUser(param);
////			//System.out.println("Vresult toString: "+"\n"+vRsult.toString());
////			Get_sampleImage_result getSampleResult= sf.getSampleImage(Bparam);
////		//	System.out.print("This is getSampleResultToString: "+getSampleResult.toString());
////			Download_batch_result dwnldresult = sf.downloadBatch(dparam);
////			//System.out.println("This is download batch result to string:");
////			//System.out.print(dwnldresult.toString());
//			Get_fields_result gfresult = sf.getFields(gfparam);
//			System.out.println("This is get fields result to string:");
//			System.out.print(gfresult.toString());
////
////			Submit_batch_result sbresult = sf.submitBatch(sbparam);
//////			System.out.println("This is submit batch result to string:");
//////			System.out.print(sbresult.toString());
//			
//			Search_result searchResult = sf.Search(sparam);
//			System.out.println("This is search result to string:");
//			System.out.print(searchResult.toString());
//
//		
//		
//		} catch (ServerException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}



	}

}
