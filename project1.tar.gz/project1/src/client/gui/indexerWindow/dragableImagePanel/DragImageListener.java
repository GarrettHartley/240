package client.gui.indexerWindow.dragableImagePanel;

public interface DragImageListener {
	void translationChanged(int w_newTranslateX, int w_newTranslateY);
}
